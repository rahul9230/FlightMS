import { Component, OnInit } from '@angular/core';
import { ServiceService } from '../service.service';
import { Router } from '@angular/router';
import { Flight } from '../Flight';

@Component({
  selector: 'app-addflight',
  templateUrl: './addflight.component.html',
  styleUrls: ['./addflight.component.css']
})
export class AddflightComponent implements OnInit {

 

  constructor(private flightapiservice:ServiceService, private route:Router) { }

  flight:Flight;
  ngOnInit(): void {
    this.flight=new Flight();
  }

  add()
  {
    this.flightapiservice.addFlight(this.flight).subscribe(
      (success)=>
      {
        alert("Flight Added Successfully");
        
      },
      (error)=>
      {
        alert("Failed to Add Flight");
      }

      
    )

    this.gotoList();
  }

  onSubmit() {
    this.add();
  }

  gotoList() {
    this.route.navigate(['/view-flight']);
  }



}
