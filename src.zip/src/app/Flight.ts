import { Time } from '@angular/common';

export class Flight{

  flightNumber:number;
  flightModel:string;
  carrierName:string;
  seatCapacity:number;
  

}
export class FlightList{

  public flightList : Flight[];

}