export interface Authentication {
}
