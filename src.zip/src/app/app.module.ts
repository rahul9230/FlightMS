import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { FormsModule } from '@angular/forms'

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { CustomerComponent } from './customer/customer.component';
import { AdminComponent } from './admin/admin.component';
import { HomePageComponent } from './home-page/home-page.component';
import { AddAirportComponent } from './add-airport/add-airport.component';
import { ViewAirportComponent } from './view-airport/view-airport.component';
import { ViewAirportlistComponent } from './view-airportlist/view-airportlist.component';
import { CheckFlightWithIdComponent } from './check-flight-with-id/check-flight-with-id.component';
import { CheckBySourceAndDestinationComponent } from './check-by-source-and-destination/check-by-source-and-destination.component';
import { CheckTheSeatsComponent } from './check-the-seats/check-the-seats.component';
import { AddComponent } from './add-schedule/add.component';
import { ViewComponent } from './view-schedule/view.component';
import { ModifyComponent } from './modify-schedule/modify.component';
import { DeleteComponent } from './delete-schedule/delete.component';

import { AddflightComponent } from './add-flight/addflight.component';
import { ViewflightComponent } from './view-flight/viewflight.component';
import { ModifyflightComponent } from './modify-flight/modifyflight.component';
import { SearchflightComponent } from './search-flight/searchflight.component';
import { AddBookingComponent } from './add-booking/add-booking.component';
import { ViewBookingComponent } from './view-booking/view-booking.component';
import { BookingListComponent } from './booking-list/booking-list.component';
import { DeleteBookingComponent } from './delete-booking/delete-booking.component';
import { ModifyBookingComponent } from './modify-booking/modify-booking.component';
import { AddPassengerComponent } from './add-passenger/add-passenger.component';
import { ViewPassengerComponent } from './view-passenger/view-passenger.component';
import { PassengerListComponent } from './passenger-list/passenger-list.component';
import { UpdatePassengerComponent } from './update-passenger/update-passenger.component';
import { HeaderComponent } from './header/header.component';
import { FooterComponent } from './footer/footer.component';

import { AddAccountComponent } from './add-account/add-account.component';
import { LoginComponent } from './login/login.component';
import { AuthenticationInterceptor } from './authentication.interceptor';
import { ViewAllFlightsComponent } from './view-all-flights/view-all-flights.component';
import { LogoutComponent } from './logout/logout.component';
import { ViewFinalBookingComponent } from './view-final-booking/view-final-booking.component';


@NgModule({
  declarations: [
    AppComponent,
    
    
    AdminComponent,
    CustomerComponent,
    AddAirportComponent,
    ViewAirportComponent,
    ViewAirportlistComponent,
    CheckFlightWithIdComponent,
    AddComponent,
    ViewComponent,
    ModifyComponent,
    DeleteComponent,
    
    
    CheckBySourceAndDestinationComponent,
    CheckTheSeatsComponent,
    
    HomePageComponent,
    
    AddflightComponent,
    
    ViewflightComponent,
    
    ModifyflightComponent,
    
    SearchflightComponent,

    AddBookingComponent,
    ViewBookingComponent,
    
    BookingListComponent,
    DeleteBookingComponent,
    ModifyBookingComponent,
    AddPassengerComponent,
    
    ViewPassengerComponent,
    PassengerListComponent,
    UpdatePassengerComponent,
    HeaderComponent,
    FooterComponent,
    
    AddAccountComponent,
    LoginComponent,
    ViewAllFlightsComponent,
    LogoutComponent,
    ViewFinalBookingComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    
    FormsModule
  ],
  providers: [{
    provide:HTTP_INTERCEPTORS,
    useClass:AuthenticationInterceptor,
    multi:true
  }],
  bootstrap: [AppComponent]
})
export class AppModule { }
