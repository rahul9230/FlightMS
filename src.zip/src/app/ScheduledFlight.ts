import { Schedule } from './Schedule';

export class ScheduledFlight{
    scheduledFlightId:number;
  availableSeats:number;
  flightNumber:number;
  schedule:Schedule;

}