import { Component, OnInit } from '@angular/core';
import { ScheduledFlight } from '../ScheduledFlight';
import { ServiceService } from '../service.service';
import { Booking } from '../Booking';
import { User } from '../User';
import { Router } from '@angular/router';

@Component({
  selector: 'app-view-all-flights',
  templateUrl: './view-all-flights.component.html',
  styleUrls: ['./view-all-flights.component.css']
})
export class ViewAllFlightsComponent implements OnInit {

  schedules:ScheduledFlight[];
  schedule : ScheduledFlight;
  booking: Booking;
  user: User;


  constructor(private scheservice:ServiceService,private  router : Router) {

    this.booking = new Booking();

   }

  ngOnInit(): void {
    this.scheservice.viewAllScheduledFlights().subscribe(
      (schedules)=>{
      this.schedules=schedules.scheduledFlightList;
      })
}
 
makeBooking(){

  // this.booking.flightNumber = this.flightNumber ;

 //  this.booking.userId =  this.scheservice. ;

  // console.log(this.user);

  this.router.navigate(['/customer/add-booking']);

  

}

}

