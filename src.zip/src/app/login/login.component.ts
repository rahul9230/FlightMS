import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

import { User } from '../User';
import { UserCredentials } from '../UserCredentials';
import { AuthenticationServiceService } from '../authentication-service.service';
import { ServiceService } from '../service.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  constructor(private router:Router, public service: ServiceService,public authService:AuthenticationServiceService ) { }
  userCredentials:UserCredentials;
  user:User;
  isAdmin:string;

  ngOnInit(): void {
    this.userCredentials=new UserCredentials();
    
  }

  getType():string{

    this.service.getUserByUsername(this.userCredentials.username).subscribe(
      (b)=>{
        console.log(b)
        console.log(b.userType.toUpperCase())
        if(b.userType.toUpperCase().match("ADMIN")){
          this.isAdmin="ADMIN";
        }
        else this.isAdmin="USER";
        
      }
    )
    console.log(this.isAdmin)
    return this.isAdmin

  }
  login(){
    this.service.loginUser(this.userCredentials).subscribe(
      (success)=>{
console.log(success)
        if(this.getType().match("ADMIN")){
          this.router.navigate(["/login/admin"]);
        }
        else if(this.getType().match("USER")){
          this.router.navigate(["/login/customer"]);
        }
        else{
            alert("User not found")
        }
      },
      (error)=>{alert("Invalid Credentials...Please try again!!!")}
    )
  }


  

}
      
  


