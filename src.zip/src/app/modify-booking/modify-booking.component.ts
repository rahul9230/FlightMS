import { Component, OnInit } from '@angular/core';

import { Booking } from '../Booking';
import { Router } from '@angular/router';
import { ServiceService } from '../service.service';

@Component({
  selector: 'app-modify-booking',
  templateUrl: './modify-booking.component.html',
  styleUrls: ['./modify-booking.component.css']
})
export class ModifyBookingComponent implements OnInit {

  booking:Booking;
  constructor(private router:Router,private bookingApiService:ServiceService) { }

  ngOnInit(): void {
  }

  updateBooking(){
  if(confirm("Sure to Modify/Update Booking?")){
    this.bookingApiService.updateBooking(this.booking).subscribe(
      (success)=>{
    alert("Booking with id ["+this.booking.bookingId+"] is Modified(Updated)");
    this.booking=null;
      },
      (error)=>{
        alert("Modification(Update) Failed");
      }
  
    );
  }
}
}
