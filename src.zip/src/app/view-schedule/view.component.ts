import { Component, OnInit } from '@angular/core';

import { ScheduledFlight } from '../ScheduledFlight';
import { ServiceService } from '../service.service';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-view',
  templateUrl: './view.component.html',
  styleUrls: ['./view.component.css']
})
export class ViewComponent implements OnInit {

  //scheduledFlight : ScheduleFlight;
  constructor(private scheservice:ServiceService, private route : ActivatedRoute, private router : Router) { }
 // schedules1:Array<scheduledFlight.schedule>; 
  schedules:ScheduledFlight[];
  schedule : ScheduledFlight;

  ngOnInit(): void {
    this.scheservice.view().subscribe(
      (schedules)=>{
      this.schedules=schedules.scheduledFlightList;
 
      console.log(schedules)
      console.log(schedules.scheduledFlightList);

    }
    );
  }

  modify(scheduledFlightId) {

    this.router.navigate(['/modify/'+scheduledFlightId]);
  
  
  }

}
