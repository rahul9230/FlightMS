import { Component, OnInit } from '@angular/core';

import { Passenger } from '../Passenger';
import { Router } from '@angular/router';
import { ServiceService } from '../service.service';


@Component({
  selector: 'app-passenger-list',
  templateUrl: './passenger-list.component.html',
  styleUrls: ['./passenger-list.component.css']
})
export class PassengerListComponent implements OnInit {
passengers:Array<Passenger> ;
passenger :Passenger= new Passenger();
  constructor(private passengerApiService:ServiceService) { }

ngOnInit(): void {

  this.passengerApiService.getAllPassengers().subscribe(
    response => this.handleSuccessfulResponse(response),);
  }
  handleSuccessfulResponse(response){
      this.passengers=response.passengerList;
      console.log(this.passengers);
}
      delete(passengerNum): void { if (confirm("Are you sure to delete"))
      console.log(passengerNum);
      this.passengerApiService.deletePassenger(passengerNum)
      .subscribe(data => {
        this.passengers= this.passengers.filter(u => u !== passengerNum);
        alert("Passenger with number ["+this.passenger.passengerNum+"] Deleted");

      });


    }}
    
      
      
    


 




