import { Component, OnInit } from '@angular/core';
import { Time } from '@angular/common';

import { ScheduledFlight } from '../ScheduledFlight';
import { ServiceService } from '../service.service';
import { Schedule } from '../Schedule';
import { Router, ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-modify',
  templateUrl: './modify.component.html',
  styleUrls: ['./modify.component.css']
})
export class ModifyComponent implements OnInit {

  scheduleFlight:ScheduledFlight;
  modifyCode : number;
  constructor(private service:ServiceService, private route : ActivatedRoute ) { 

    this.scheduleFlight = new ScheduledFlight();
    this.scheduleFlight.schedule = new Schedule();

  }

  ngOnInit(): void {

    this.route.params.subscribe(param => {
      this.modifyCode = param["scheduledFlightId"];
      this.service.getScheduledFlight(this.modifyCode).subscribe(
        (response) => {
          this.scheduleFlight = response;
          this.service.scheduledFlight=this.scheduleFlight;
        }
      );
    }
    )

  }

  modify()
  {
    this.service.modify(this.scheduleFlight).subscribe(
      (success)=>
      {
        alert("Modified");
      },
      (error)=>
      {
        alert("not found")
      }
      )
    
  }
}
