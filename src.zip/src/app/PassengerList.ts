import { Passenger } from './Passenger';

export class PassengerList
{
    public passengers:Array<Passenger>;
}