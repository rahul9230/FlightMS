import { Component, OnInit } from '@angular/core';

import { Router, ActivatedRoute } from '@angular/router';

import { HttpClient } from '@angular/common/http';
import { ServiceService } from '../service.service';


@Component({
  selector: 'app-check-the-seats',
  templateUrl: './check-the-seats.component.html',
  styleUrls: ['./check-the-seats.component.css']
})
export class CheckTheSeatsComponent implements OnInit {

  constructor(private router:Router, private userDataService: ServiceService, private route: ActivatedRoute, private httpClient: HttpClient) { }
  available: number;
  availableSeats: number;
  requiredSeats: number;
  flightNumber: number;
  ngOnInit(): void {
  }

  search() {

    console.log(this.availableSeats);
    console.log(this.flightNumber);
    // this.httpClient.get(this.baseUrl+"/"+this.flightNumber+"/"+this.availableSeats, {responseType: 'text'});
    this.userDataService.checkAvailableSeatsAndFlightNumber(this.flightNumber, this.availableSeats).subscribe( 
      (success) => {
          console.log("Seats are available");
          alert("Seats are available");
          console.log(success);
      },

      (error) => {
        console.log("Seats are not available");
        alert("Seats are not available");
        console.log(error);
      }
    )
  }
}


