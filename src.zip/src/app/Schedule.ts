import { ScheduledFlight } from './ScheduledFlight';
import { Time } from '@angular/common';

export class Schedule{

    scheduleId:number;
    sourceAirport:string;
    destinationAirport:string;
    arrivalTime:Time;
    departureTime:Time;
   
  }
  export class ScheduleFlightList{
  
    public scheduledFlightList:ScheduledFlight[];
   
  }