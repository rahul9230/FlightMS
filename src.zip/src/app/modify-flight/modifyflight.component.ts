import { Component, OnInit } from '@angular/core';
import { Flight } from '../Flight';
import { ServiceService } from '../service.service';
import { Router, ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-modifyflight',
  templateUrl: './modifyflight.component.html',
  styleUrls: ['./modifyflight.component.css']
})
export class ModifyflightComponent implements OnInit {

  modifyCode:number;

  flight:Flight;
  constructor(private flightapiservice:ServiceService, private router: Router, private route: ActivatedRoute) {
    this.flight=new Flight();
   }

  ngOnInit(): void {
    this.route.params.subscribe(param => {
      this.modifyCode = param["flightNumber"];
      this.flightapiservice.getFlightById(this.modifyCode).subscribe(
        (response) => {
          this.flight = response;
          this.flightapiservice.flight=this.flight;
        }
      );
    }
    )
    
      
      
  
  }

  modify() {
    this.flightapiservice.modifyFlight(this.flight)
    .subscribe(data =>alert("flight modified successfully"), error => alert("flight modification failed"));
    this.gotoList();
  }

  

  gotoList() {
    this.router.navigate(['/view-flight'])
  }


}
