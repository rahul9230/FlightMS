import { Component, OnInit } from '@angular/core';
import { Passenger } from '../Passenger';

import { ServiceService } from '../service.service';

@Component({
  selector: 'app-add-passenger',
  templateUrl: './add-passenger.component.html',
  styleUrls: ['./add-passenger.component.css']
})
export class AddPassengerComponent implements OnInit {

  constructor(private passengerApiService:ServiceService) { }
  passenger:Passenger;
  ngOnInit(): void {
    this.passenger=new Passenger();
  }

  addPassenger():void {
    console.log(this.passenger);{
    this.passengerApiService.addPassenger(this.passenger).subscribe(
      (success)=>{
        alert("Passenger Added successfully");
      },
      (error)=>{
        alert("Error:passenger not Added");
      }
    )
  }

  }}
  


