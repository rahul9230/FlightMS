import { Component, OnInit } from '@angular/core';

import { ScheduledFlight } from '../ScheduledFlight';
import { ServiceService } from '../service.service';

@Component({
  selector: 'app-delete',
  templateUrl: './delete.component.html',
  styleUrls: ['./delete.component.css']
})
export class DeleteComponent implements OnInit {


  scheduledFlightId: ScheduledFlight;

  constructor(private scheduleService:ServiceService) { }

  ngOnInit(): void {
  }

delete(){

this.scheduleService.delete(this.scheduledFlightId).subscribe(

  (success)=>{

confirm("Are you sure to delete!");
alert("Deleted");
  },
  (error)=>{
  alert(" Id Not Found");
}
)

}

}
