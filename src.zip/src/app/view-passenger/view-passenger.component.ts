import { Component, OnInit } from '@angular/core';

import { Passenger } from '../Passenger';
import { ActivatedRoute , Router} from '@angular/router';
import { ServiceService } from '../service.service';


@Component({
  selector: 'app-view-passenger',
  templateUrl: './view-passenger.component.html',
  styleUrls: ['./view-passenger.component.css']
})
export class ViewPassengerComponent implements OnInit {
  
  constructor(private passengerApiService:ServiceService, private route:ActivatedRoute,private router:Router ) { }
  passengerNumber:number;
  ngOnInit(): void {
    
    this.route.params.subscribe(
      (param)=>{
        this.searchPassenger(param["number"]);
      }
    )
  }
  public passenger:Passenger;

    searchPassenger(passengerNumber:number){
      this.passengerApiService.getPassengerInfo(passengerNumber).subscribe(
        (response)=>{
          this.passenger=response;
          console.log(this.passenger)
        },
        (error)=>{
          this.passenger=null;
          alert("Passenger Not Found");
        }
      );
  }
  updatePassenger(){
    this.router.navigate(["/update-passenger"]);
  }

  deletePassenger(){
    if(confirm("Sure to Delete?")){
      this.passengerApiService.deletePassenger(this.passenger.passengerNum).subscribe(
        (success)=>{
      alert("Passenger with number ["+this.passenger.passengerNum+"] Deleted");
        });
      }}}
    
    
    
    
    
    

